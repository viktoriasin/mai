drop table FILE_SYSTEM;
create table FILE_SYSTEM(
  ID INTEGER,
  PARENT_ID INTEGER,
  NAME VARCHAR2(2000),
  TYPE VARCHAR2(10),
  FILE_SIZE INTEGER
);

alter table FILE_SYSTEM add primary key (ID);
alter table FILE_SYSTEM add constraint FK_FILE_SYSTEM_PARENT_ID foreign key (PARENT_ID) references FILE_SYSTEM(ID);
create index I_FILE_SYSTEM_PARENT_ID on FILE_SYSTEM(PARENT_ID);
