-- Каждый месяц компания выдает премию в размере 5%
-- от суммы продаж менеджеру, который за предыдущие 3 месяца
-- продал товаров на самую большую сумму
-- Выведите месяц, manager_id, manager_first_name, manager_last_name, премию за период с января по декабрь 2014 года

-- Шаг 1.
-- В задании требуется обрабатывать временные интервалы. это можно сделать с помощью
--функции sql months_between (date1,date2)
-- если data1 > data2, тo результат положительный, иначе - отрицательный

select months_between('06-Jun-2013','01-jan-2013') from dual;

-- В результате получается вещественное число 5.16129032, которое нас не устраивает
-- усечем его до целого с помощью sql функции trunc

select trunc(months_between('06-jun-2013','01-jan-2013')) month from dual;

-- В результате получим целое число месяцев - 5 , назовем его month

-- Применим эту реализацию к условию задания

--Подсчитаем количество месяцев + 1(так как возможная премия будет в следующем месяце)
--по всем продажам, которое будет участвовать в
--отборе 3-х последних в заданный условием задания
--временной период: 10,11,12 месяцы 2013 года, 1-12 месяцы 2014

select TRUNC(MONTHS_BETWEEN(sale_date, '01-jan-2014')) + 1 MONTH
from mv_fact_sale where sale_date between TO_DATE('01-oct-2013', 'DD-MON-YYYY') and TO_DATE('31-dec-2014', 'DD-MON-YYYY');

--выбрано 4190 строк

--добавим в выборку требуемые в задании атрибуты
select TRUNC(MONTHS_BETWEEN(sale_date, '01-jan-2014')) + 1 MONTH,
       manager_id,
       manager_first_name,
       manager_last_name
from mv_fact_sale where sale_date between '01-oct-2013' and '31-dec-2014';

--теперь добавим суммирование по продажам и группировку по комплексу

select TRUNC(MONTHS_BETWEEN(sale_date, '01-jan-2014')) + 1 MONTH,
       manager_id,
       manager_first_name,
       manager_last_name,
       sum(sale_amount) SALE_AMOUNT
from mv_fact_sale
where sale_date between '01-oct-2013' and '31-dec-2014'
    --
group by (
    TRUNC(MONTHS_BETWEEN(sale_date, '01-jan-2014')) + 1,
    manager_id,
    manager_first_name,
    manager_last_name )
having MANAGER_FIRST_NAME = 'Eugene';

-- именуем выборку STEP1

( select TRUNC(MONTHS_BETWEEN(sale_date, '01-jan-2014')) + 1 MONTH,
         manager_id,
         manager_first_name,
         manager_last_name,
         sum(sale_amount) SALE_AMOUNT
  from mv_fact_sale
  where sale_date between '01-oct-2013' and '31-dec-2014'
    --
  group by (
      TRUNC(MONTHS_BETWEEN(sale_date, '01-jan-2014')) + 1,
      manager_id,
      manager_first_name,
      manager_last_name )) STEP1;

-- и шаг 1 завершен выбрана 751 запись

--Шаг 2.
-- теперь обернем STEP1, группировкой продаж по равенству manager_id за 3 месяца,
-- начиная с даты продажи

select MONTH, manager_id, manager_first_name, manager_last_name,
       SUM(sale_amount) OVER (PARTITION BY manager_id order by MONTH RANGE 3 PRECEDING) PERIOD_SALE_AMOUNT
from
     ( select TRUNC(MONTHS_BETWEEN(sale_date, '01-jan-2014')) + 1 MONTH,
              manager_id,
              manager_first_name,
              manager_last_name,
              sum(sale_amount) SALE_AMOUNT
       from mv_fact_sale
       where sale_date between '01-oct-2013' and '31-dec-2014'
         --
       group by (
           TRUNC(MONTHS_BETWEEN(sale_date, '01-jan-2014')) + 1,
           manager_id,
           manager_first_name,
           manager_last_name )) STEP1;

-- именуем выборку STEP2

(select MONTH, manager_id, manager_first_name, manager_last_name,
        SUM(sale_amount) OVER (PARTITION BY manager_id order by MONTH RANGE 3 PRECEDING) PERIOD_SALE_AMOUNT
 from
      ( select TRUNC(MONTHS_BETWEEN(sale_date, '01-jan-2014')) + 1 MONTH,
               manager_id,
               manager_first_name,
               manager_last_name,
               sum(sale_amount) SALE_AMOUNT
        from mv_fact_sale
        where sale_date between '01-oct-2013' and '31-dec-2014'
          --
        group by (
            TRUNC(MONTHS_BETWEEN(sale_date, '01-jan-2014')) + 1,
            manager_id,
            manager_first_name,
            manager_last_name )) STEP1) STEP2;

-- шаг 2 завершен выбрана 751 запись
--
-- Шаг 3
-- Обернем STEP2 запросом поиска MAX, группировкой по равенству периода
--
select MONTH, manager_id, manager_first_name, manager_last_name, PERIOD_SALE_AMOUNT,
       MAX(PERIOD_SALE_AMOUNT) over (partition by MONTH) MAX_MONTH_SALE_AMOUNT
from
     (select MONTH, manager_id, manager_first_name, manager_last_name,
             SUM(sale_amount) OVER (PARTITION BY manager_id order by MONTH RANGE 3 PRECEDING) PERIOD_SALE_AMOUNT
      from
           ( select TRUNC(MONTHS_BETWEEN(sale_date, '01-jan-2014')) + 1 MONTH,
                    manager_id,
                    manager_first_name,
                    manager_last_name,
                    sum(sale_amount) SALE_AMOUNT
             from mv_fact_sale
             where sale_date between '01-oct-2013' and '31-dec-2014'
               --
             group by (
                 TRUNC(MONTHS_BETWEEN(sale_date, '01-jan-2014')) + 1,
                 manager_id,
                 manager_first_name,
                 manager_last_name )) STEP1) STEP2;

-- именуем  выборку STEP3

(select MONTH, manager_id, manager_first_name, manager_last_name, PERIOD_SALE_AMOUNT,
        MAX(PERIOD_SALE_AMOUNT) over (partition by MONTH) MAX_MONTH_SALE_AMOUNT
 from
      (select MONTH, manager_id, manager_first_name, manager_last_name,
              SUM(sale_amount) OVER (PARTITION BY manager_id order by MONTH RANGE 3 PRECEDING) PERIOD_SALE_AMOUNT
       from
            ( select TRUNC(MONTHS_BETWEEN(sale_date, '01-jan-2014')) + 1 MONTH,
                     manager_id,
                     manager_first_name,
                     manager_last_name,
                     sum(sale_amount) SALE_AMOUNT
              from mv_fact_sale
              where sale_date between '01-oct-2013' and '31-dec-2014'
                --
              group by (
                  TRUNC(MONTHS_BETWEEN(sale_date, '01-jan-2014')) + 1,
                  manager_id,
                  manager_first_name,
                  manager_last_name )) STEP1) STEP2) STEP3;

--шаг 3 завершен, выбрана 751 запись

--Заключительный шаг
--обернем STEP3 запросом, в которм вычислим вознаграждение, того менеджера, который продал
--товаров на максимальную сумму за предыдущие 3 месяца

select MONTH, manager_id, manager_first_name, manager_last_name, PERIOD_SALE_AMOUNT, 0.05 * PERIOD_SALE_AMOUNT BONUS_AMOUNT
from
     (select MONTH, manager_id, manager_first_name, manager_last_name, PERIOD_SALE_AMOUNT,
             MAX(PERIOD_SALE_AMOUNT) over (partition by MONTH) MAX_MONTH_SALE_AMOUNT
      from
           (select MONTH, manager_id, manager_first_name, manager_last_name,
                   SUM(sale_amount) OVER (PARTITION BY manager_id order by MONTH RANGE 3 PRECEDING) PERIOD_SALE_AMOUNT
            from
                 ( select TRUNC(MONTHS_BETWEEN(sale_date, '01-jan-2014')) + 1 MONTH,
                          manager_id,
                          manager_first_name,
                          manager_last_name,
                          sum(sale_amount) SALE_AMOUNT
                   from mv_fact_sale
                   where sale_date between '01-oct-2013' and '31-dec-2014'
                     --
                   group by (
                       TRUNC(MONTHS_BETWEEN(sale_date, '01-jan-2014')) + 1,
                       manager_id,
                       manager_first_name,
                       manager_last_name )) STEP1) STEP2) STEP3
    --
where PERIOD_SALE_AMOUNT = MAX_MONTH_SALE_AMOUNT and MONTH > 0;

-- результат

MONTH MANAGER_ID SUBSTR(MANAGER_FIRST_NAME,1,10)          SUBSTR(MANAGER_LAST_NAME,1,10)           BONUS_AMOUNT
---------- ---------- ---------------------------------------- ---------------------------------------- ------------
1        362 Eugene                                   Miller                                      13942.096
2        969 Gregory                                  Cox                                         15049.106
3        191 Clarence                                 Woods                                      14948.0415
4        214 Lawrence                                 Gordon                                      12527.494
5        510 Jacqueline                               Alvarez                                    11597.9105
6          1 Walter                                   Ford                                       12245.8705
7        456 Paul                                     Moore                                      13007.9145
8          1 Walter                                   Ford                                       11953.5325
9         66 Jesse                                    Graham                                     14972.1865
10        945 Norma                                    Sanders                                      12020.18
11         65 Michael                                  White                                      10247.8135

MONTH MANAGER_ID SUBSTR(MANAGER_FIRST_NAME,1,10)          SUBSTR(MANAGER_LAST_NAME,1,10)           BONUS_AMOUNT
---------- ---------- ---------------------------------------- ---------------------------------------- ------------
12        287 Peter                                    Bowman                                      9886.2555

12 rows selected.


-- запрос может быть также реализован с помощью WITH


WITH
STEP1 as (select TRUNC(MONTHS_BETWEEN(sale_date, '01-jan-2014')) + 1 MONTH,
manager_id,
manager_first_name,
manager_last_name,
sum(sale_amount) SALE_AMOUNT
from MV_FACT_SALE
where sale_date between '01-oct-2013' and '31-dec-2014'
group by TRUNC(MONTHS_BETWEEN(sale_date, '01-jan-2014')) + 1,
manager_id,
manager_first_name,
manager_last_name),
--
STEP2 as (select MONTH, manager_id, manager_first_name, manager_last_name,
--
SUM(SALE_AMOUNT) OVER (PARTITION BY manager_id order by month range 3 preceding) PERIOD_SALE_AMOUNT
from STEP1),
--
STEP3 as (select MONTH, manager_id, manager_first_name, manager_last_name, PERIOD_SALE_AMOUNT,
--
MAX (PERIOD_SALE_AMOUNT) OVER (PARTITION BY MONTH) MAX_MONTH_SALE_AMOUNT
from STEP2)
--
select MONTH,
       manager_id,
       substr(manager_first_name, 1, 10),
       substr(manager_last_name, 1, 10),
       0.05 * PERIOD_SALE_AMOUNT BONUS_AMOUNT
from STEP3
where PERIOD_SALE_AMOUNT = MAX_MONTH_SALE_AMOUNT
  and MONTH > 0;





with TV_MANAGER_SALES as (select TRUNC(MONTHS_BETWEEN(SALE_DATE, TO_DATE('01.01.2014', 'DD.MM.YYYY'))) + 1 MONTH,
                                 manager_id,
                                 MANAGER_FIRST_NAME,
                                 MANAGER_LAST_NAME,
                                 sum(SALE_AMOUNT) SALE_AMOUNT
                          from MV_FACT_SALE
                          where SALE_DATE between
                                    TO_DATE('01.10.2013', 'DD.MM.YYYY') and
                                    TO_DATE('31.12.2014', 'DD.MM.YYYY')
                          group by TRUNC(MONTHS_BETWEEN(SALE_DATE, TO_DATE('01.01.2014', 'DD.MM.YYYY'))) + 1,
                                   manager_id,
                                   MANAGER_FIRST_NAME,
                                   MANAGER_LAST_NAME
    ),
     TV_MANAGER_3MONTHS_SALES as (
                          select MONTH, MANAGER_ID, MANAGER_FIRST_NAME, MANAGER_LAST_NAME,
                                 SUM(SALE_AMOUNT) over (partition by MANAGER_ID order by month range 3 preceding) PERIOD_SALE_AMOUNT
                          from TV_MANAGER_SALES
    ),
     TV_MAX_SALE_AMOUNT as (
                          select MONTH, MANAGER_ID, MANAGER_FIRST_NAME, MANAGER_LAST_NAME, PERIOD_SALE_AMOUNT,
                                 MAX(PERIOD_SALE_AMOUNT) over (partition by MONTH) MAX_MONTH_SALE_AMOUNT
                          from TV_MANAGER_3MONTHS_SALES
    )
select MONTH, MANAGER_ID, MANAGER_FIRST_NAME, MANAGER_LAST_NAME, 0.05 * PERIOD_SALE_AMOUNT BONUS_AMOUNT
from TV_MAX_SALE_AMOUNT
where PERIOD_SALE_AMOUNT = MAX_MONTH_SALE_AMOUNT and MONTH > 0;